#!/usr/bin/env python3

import csv
from datetime import datetime
from dateutil import parser
from uuid import uuid4

from indicators.config.configRepository import get_mysql_config
from indicators.external.mysql_connection import MysqlConnection

DATA_FOLDER = "./data/"

REPORTS_FILEPATH = DATA_FOLDER + 'data/reports.csv'
REPORTS_RSU_FILEPATH = DATA_FOLDER + 'data/reports_rsu.csv'

UUID_PROM_ADMINISTRATIVO = '1ecebbb0-28e6-11e9-8e4b-0242ac180002'


def insert_reports_data(mysql_connection):
    cursor = mysql_connection.cursor()

    insert_rol_query = ("INSERT INTO report "
                        "(town_ine, kpi_id, date, value, user_uuid, insertion_date, last_update_date) "
                        "VALUES (%(town_ine)s, %(kpi_id)s, %(date)s, %(value)s, %(user_uuid)s, %(insertion_date)s, %(last_update_date)s)")

    with open(REPORTS_FILEPATH, newline='') as csvfile:
        rol_data = csv.DictReader(csvfile, delimiter=';', quotechar='"')

        for row in rol_data:
            data_to_be_inserted = {
                'town_ine': row['ine'],
                'kpi_id': row['kpi_id'],
                'date': str(parser.parse(row['fecha']).date()),
                'value': row['valor'],
                'user_uuid': UUID_PROM_ADMINISTRATIVO,
                'insertion_date': datetime.now(),
                'last_update_date': datetime.now(),
            }
            cursor.execute(insert_rol_query, data_to_be_inserted)
            mysql_connection.commit()


def insert_reports_data_rsu(mysql_connection):
    cursor = mysql_connection.cursor()

    insert_rol_query = ("INSERT INTO report_rsu "
                        "(kpi_id, date, kg, user_uuid, insertion_date, last_update_date) "
                        "VALUES (%(kpi_id)s, %(date)s, %(kg)s, %(user_uuid)s, %(insertion_date)s, %(last_update_date)s)")

    with open(REPORTS_RSU_FILEPATH, newline='') as csvfile:
        rol_data = csv.DictReader(csvfile, delimiter=',', quotechar='"')
        # kpi_id,fecha,kg
        for row in rol_data:
            data_to_be_inserted = {
                'kpi_id': row['kpi_id'],
                'date': str(parser.parse(row['fecha']).date()),
                'kg': row['kg'],
                'user_uuid': UUID_PROM_ADMINISTRATIVO,
                'insertion_date': datetime.now(),
                'last_update_date': datetime.now(),
            }
            cursor.execute(insert_rol_query, data_to_be_inserted)
            mysql_connection.commit()


if __name__ == '__main__':
    mysql_config = get_mysql_config()

    mysql_connection = MysqlConnection().get_connection()

    mysql_connection.database = mysql_config['domain_database']

    insert_reports_data(mysql_connection)
    insert_reports_data_rsu(mysql_connection)

    mysql_connection.close()
