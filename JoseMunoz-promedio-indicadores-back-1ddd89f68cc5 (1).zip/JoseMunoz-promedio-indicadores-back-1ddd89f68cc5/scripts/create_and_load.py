#!/usr/bin/env python3

import csv

from indicators.config.configRepository import get_mysql_config
from indicators.external.mysql_connection import MysqlConnection

DATA_FOLDER = "./data/"

SQL_FILE = DATA_FOLDER + 'schema.sql'
KPI_FILEPATH = DATA_FOLDER + 'data/kpi.csv'
USER_FILEPATH = DATA_FOLDER + 'data/user.csv'
TOWN_FILEPATH = DATA_FOLDER + 'data/town.csv'
ROL_FILEPATH = DATA_FOLDER + 'data/rol.csv'
ACCESS_INDICATORS_FILEPATH = DATA_FOLDER + 'data/accessIndicators.csv'


def execute_scripts_from_file(mysql_connection, filename):
    cursor = mysql_connection.cursor()
    fd = open(filename, 'r')
    sql_file = fd.read()
    fd.close()
    sql_commands = sql_file.split(';')

    for command in sql_commands:
        if command.strip() != '':
            cursor.execute(command)
    cursor.close()


def recreate_db(mysql_connection, database_name):
    cursor = mysql_connection.cursor()
    cursor.execute("DROP DATABASE IF EXISTS {};".format(database_name))
    cursor.close()

    cursor = mysql_connection.cursor()
    cursor.execute("CREATE DATABASE {};".format(database_name))
    cursor.close()


def insert_rol_data(mysql_connection):
    cursor = mysql_connection.cursor()

    insert_rol_query = ("INSERT INTO rol "
                        "(id, name) "
                        "VALUES (%(id)s, %(name)s)")

    with open(ROL_FILEPATH, newline='') as csvfile:
        rol_data = csv.DictReader(csvfile, delimiter=',', quotechar='"')

        for row in rol_data:
            data_to_be_inserted = {
                'id': row['id'],
                'name': row['name']
            }
            cursor.execute(insert_rol_query, data_to_be_inserted)
            mysql_connection.commit()

    cursor.close()


def insert_town_data(mysql_connection):
    cursor = mysql_connection.cursor()

    insert_town_query = ("INSERT INTO town "
                         "(ine, name) "
                         "VALUES (%(ine)s, %(name)s)")

    with open(TOWN_FILEPATH, newline='') as csvfile:
        town_data = csv.DictReader(csvfile, delimiter=',', quotechar='"')

        for row in town_data:
            data_to_be_inserted = {
                'ine': row['ine'],
                'name': row['name']
            }
            cursor.execute(insert_town_query, data_to_be_inserted)
            mysql_connection.commit()

    cursor.close()


def insert_kpi_data(mysql_connection, kpi_file_path):
    cursor = mysql_connection.cursor()

    insert_kpi_query = ("""
          INSERT INTO kpi (id, name, unit_measure, periodicity, type, subtype, description)
          VALUES (%(id)s, %(name)s, %(unit_measure)s, %(periodicity)s, %(type)s, %(subtype)s, %(description)s)
                        """)

    with open(kpi_file_path, newline='') as csvfile:
        kpi_data = csv.DictReader(csvfile, delimiter=',', quotechar='"')

        for row in kpi_data:
            data_to_be_inserted = {
                'id': row['id'],
                'name': row['name'],
                'unit_measure': row['unit_measure'],
                'periodicity': row['periodicity'],
                'type': row['type'],
                'subtype': row['subtype'],
                'description': row['description']
            }
            cursor.execute(insert_kpi_query, data_to_be_inserted)
            mysql_connection.commit()

    cursor.close()


def insert_user_data(mysql_connection):
    cursor = mysql_connection.cursor()

    insert_user_query = ("INSERT INTO user "
                         "(uuid, email, name, rol_id, firebase_uid) "
                         "VALUES (%(uuid)s, %(email)s, %(name)s, %(rol_id)s, %(firebase_uid)s)")

    with open(USER_FILEPATH, newline='') as csvfile:
        user_data = csv.DictReader(csvfile, delimiter=',', quotechar='"')

        for row in user_data:
            data_to_be_inserted = {
                'uuid': row['uuid'],
                'email': row['email'],
                'name': row['name'],
                'rol_id': row['rol_id'],
                'firebase_uid': row['firebase_uid']
            }
            cursor.execute(insert_user_query, data_to_be_inserted)
            mysql_connection.commit()

    cursor.close()


def insert_access_indicators_data(mysql_connection):
    cursor = mysql_connection.cursor()

    insert_access_indicators_query = ("INSERT INTO user_access_to_kpi_indicator "
                         "(user_uuid, town_ine, kpi_id) "
                         "VALUES (%(user_uuid)s, %(town_ine)s, %(kpi_id)s)")

    with open(ACCESS_INDICATORS_FILEPATH, newline='') as csvfile:
        access_indicators_data = csv.DictReader(csvfile, delimiter=',', quotechar='"')

        for access in access_indicators_data:
            data_to_be_inserted = {
                'user_uuid': access['user_uuid'],
                'town_ine': access['town_ine'],
                'kpi_id': access['kpi_id']
            }
            cursor.execute(insert_access_indicators_query, data_to_be_inserted)
            mysql_connection.commit()

    cursor.close()


def read_data(mysql_connection):
    cursor = mysql_connection.cursor()

    query = ("SELECT ine, name FROM town;")

    cursor.execute(query)

    for (ine, name) in cursor:
        print("{} - {}".format(ine, name))

    cursor.close()


if __name__ == '__main__':
    mysql_config = get_mysql_config()

    mysql_connection = MysqlConnection().get_connection()

    recreate_db(mysql_connection, mysql_config['domain_database'])

    mysql_connection.database = mysql_config['domain_database']

    execute_scripts_from_file(mysql_connection, SQL_FILE)

    print("Database recreated")

    insert_rol_data(mysql_connection)
    insert_town_data(mysql_connection)
    insert_kpi_data(mysql_connection, KPI_FILEPATH)
    insert_user_data(mysql_connection)
    insert_access_indicators_data(mysql_connection)

    # read_data(mysql_connection)

    print("Data inserted")

    mysql_connection.close()
