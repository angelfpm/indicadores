import firebase_admin
from firebase_admin import credentials
from firebase_admin import auth
import sys

# Fetch the service account key JSON file contents
cred = credentials.Certificate('config/development/promedio-indicadores-firebase-adminsdk.json')

# Initialize the app with a service account, granting admin privileges
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://promedio-indicadores.firebaseio.com'
})

if len(sys.argv) != 2:
    print("Please introduce an email as param")
else:
    try:
        user = auth.get_user_by_email(sys.argv[1])
        print('Actual claims: ' + str(user.custom_claims))

        new_custom_claims = {
            "OWN": True
        }

        auth.set_custom_user_claims(user.uid, new_custom_claims)
        print('New claims setted')
    except Exception as inst:
        print("Error: " + str(inst))
