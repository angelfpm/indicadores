#!/usr/bin/env python3

from indicators.reporting.tokenRepository import TokenRepository

print(TokenRepository().get_token())
