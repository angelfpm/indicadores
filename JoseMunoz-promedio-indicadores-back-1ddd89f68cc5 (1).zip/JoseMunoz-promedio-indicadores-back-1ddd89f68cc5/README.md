pip freeze > requirements.txt

execute in prod: http://flask.pocoo.org/docs/1.0/server/#server
```
if __name__ == '__main__':
    app.run()
```

Access venv:
```
source ./venv/bin/activate
```

# Configs

| environment      | mysql              | firebase | fiware |
|------------------|--------------------|----------|--------|
| development      | local              | prod     | empty  |
| development-next | local              | prod     | dev    |
| preproduction    | prod from external | prod     | pre    |
| production       | prod from internal | prod     | prod   |

# Environment:

### Mysql

docker-compose -f mysql.yml up -d

sudo docker exec -i -t mysql /bin/bash

```
MYSQL_ROOT_PASSWORD: mysqlrootpassword
MYSQL_DATABASE: mysqldatabase
MYSQL_USER: mysqluser
MYSQL_PASSWORD: mysqlpassword
```

Usuario_poblaciones
	usuario-id: Int (Usuario-id)
	poblacion-id: Int (Población-Int)

TipoIndicador:
	tipo: String
		“0-10”…

Indicadores:
	id: Int
	nombre: String
	Descripción: String
	unidad: String
	tipo: String (TipoIndicador-tipo)


Reportes:
	indicador: Int (Indicadores-id)
	población: Int (Poblaciones-Int)
	fecha: date
	valor:

        userId: Int (Usuario-id)
        reportDate: date



gcloud app logs tail -s default


gcloud app browse

python -m scripts.setCustomClaims prom.administrador@door4c.com
python -m scripts.getFirebaseUserInfo prom.administrador@door4c.com
python -m indicators.reporting.manager 

https://github.com/telefonicaid/fiware-orion
http://telefonicaid.github.io/fiware-orion/api/v2/stable/
https://github.com/Fiware/catalogue/tree/master/core


https://fiware-orion.readthedocs.io/en/master/user/walkthrough_apiv2/index.html#entity-creation
https://fiware-orion.readthedocs.io/en/develop/user/structured_attribute_valued/index.html


https://swagger.lab.fiware.org/?url=https://raw.githubusercontent.com/Fiware/specifications/master/OpenAPI/ngsiv2/ngsiv2-openapi.json


https://fiware-datamodels.readthedocs.io/en/latest/
https://fiware-datamodels.readthedocs.io/en/latest/Weather/WeatherForecast/doc/spec/index.html
https://fiware-datamodels.readthedocs.io/en/latest/KeyPerformanceIndicator/doc/spec/index.html


https://www.slideshare.net/fermingalan/fiware-managing-context-information-at-large-scale
https://www.slideshare.net/fermingalan/orion-context-broker-exercises?next_slideshow=1
https://docs.google.com/presentation/d/1_fv9dB5joCsOCHlb4Ld6A-QmeIYhDzHgFHUWreGmvKU/edit#slide=id.g53c31d7074fd7bc7_0
