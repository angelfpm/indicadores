#!/usr/bin/env bash

docker network create --driver bridge promedio-indicadores || true

docker