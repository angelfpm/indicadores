USE promedio_indicadores;

CREATE TABLE town (
  ine INT NOT NULL,
  name VARCHAR(255) NOT NULL,
  PRIMARY KEY (ine)
);

CREATE TABLE rol (
  id VARCHAR(3) NOT NULL,
  name VARCHAR(255) NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE user (
  uuid VARCHAR(36) NOT NULL,
  email VARCHAR(128),
  name VARCHAR(128),
  rol_id  VARCHAR(3) NOT NULL,
  firebase_uid VARCHAR(128), /* need a */
  /* Firebase info */
  PRIMARY KEY (uuid),
  FOREIGN KEY (rol_id)
    REFERENCES rol(id)
    ON DELETE CASCADE,
  UNIQUE KEY(firebase_uid)
);

CREATE TABLE kpi (
  id VARCHAR(64) NOT NULL,
  name VARCHAR(256) NOT NULL,
  unit_measure VARCHAR(15) NOT NULL,
  periodicity VARCHAR(10) NOT NULL,  /* validate */
  type VARCHAR(20) NOT NULL,
  subtype VARCHAR(20),
  description TEXT NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE report (
  town_ine INT NOT NULL,
  kpi_id VARCHAR(64) NOT NULL,
  date DATE NOT NULL,
  value DECIMAL(15,2) NOT NULL,
  user_uuid varchar(36),
  insertion_date DATETIME NOT NULL,
  last_update_date DATETIME NOT NULL,

  PRIMARY KEY (town_ine, kpi_id, date),
  FOREIGN KEY (kpi_id)
    REFERENCES kpi(id)
    ON DELETE CASCADE,
  FOREIGN KEY (user_uuid)
    REFERENCES user(uuid)
    ON DELETE SET NULL
);

CREATE TABLE report_rsu (
  kpi_id VARCHAR(64) NOT NULL,
  date DATE NOT NULL,
  kg DECIMAL(15,2),
  impropios DECIMAL(5,2),
  user_uuid varchar(36),
  insertion_date DATETIME NOT NULL,
  last_update_date DATETIME NOT NULL,

  PRIMARY KEY (kpi_id, date),
  FOREIGN KEY (kpi_id)
    REFERENCES kpi(id)
    ON DELETE CASCADE,
  FOREIGN KEY (user_uuid)
    REFERENCES user(uuid)
    ON DELETE SET NULL
);

CREATE TABLE user_access_to_kpi_indicator (
  user_uuid VARCHAR(36) NOT NULL,
  town_ine INT NOT NULL,
  kpi_id VARCHAR(64) NOT NULL,
  PRIMARY KEY (user_uuid, town_ine, kpi_id),
  FOREIGN KEY (user_uuid)
    REFERENCES user(uuid)
    ON DELETE CASCADE,
  FOREIGN KEY (town_ine)
    REFERENCES town(ine)
    ON DELETE CASCADE,
  FOREIGN KEY (kpi_id)
    REFERENCES kpi(id)
    ON DELETE CASCADE
);

CREATE TABLE user_access_to_kpi_rsu (
  user_uuid VARCHAR(36) NOT NULL,
  kpi_id VARCHAR(64) NOT NULL,
  PRIMARY KEY (user_uuid, kpi_id),
  FOREIGN KEY (user_uuid)
    REFERENCES user(uuid)
    ON DELETE CASCADE,
  FOREIGN KEY (kpi_id)
    REFERENCES kpi(id)
    ON DELETE CASCADE
);
