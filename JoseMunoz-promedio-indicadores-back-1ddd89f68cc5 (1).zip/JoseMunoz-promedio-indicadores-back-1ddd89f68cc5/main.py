from flask import Flask, jsonify
from flask_cors import CORS

from indicators.http_interface.routes import routes

app = Flask(__name__)

CORS(app)


app.register_blueprint(routes)


@app.errorhandler(404)
def page_not_found(e):
    message = "Not found"
    return jsonify(error=404, text=message), 404


@app.errorhandler(500)
def internal_error(error):
    # TODO log error
    message = "Internal Server Error"
    return jsonify(error=500, text=message), 500
