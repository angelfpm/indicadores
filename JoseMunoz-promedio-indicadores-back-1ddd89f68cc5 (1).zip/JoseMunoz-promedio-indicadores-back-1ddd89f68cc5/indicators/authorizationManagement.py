from enum import Enum

from indicators.domain.rol import RolType
from indicators.domain.user import User


class UserFeatures(Enum):
    USER_ADMINISTRATION = "user_administration"
    ALL_KPI_ACCESS = "all_kpi_access"


def _get_user_features(user: User) -> set:
    if user.rol_id == RolType.OWN.value:
        return {
            UserFeatures.USER_ADMINISTRATION,
            UserFeatures.ALL_KPI_ACCESS
        }
    else:
        return set()


def user_has_feature(user: User, feature: UserFeatures) -> bool:
    features = _get_user_features(user)
    if feature in features:
        return True
    else:
        return False
