from datetime import date
from typing import List, Tuple

from dateutil.relativedelta import relativedelta

from indicators.domain.kpi import Kpi
from indicators.domain.report_indicator import ReportIndicator
from indicators.domain.report_rsu import ReportRsu


def render_reports_of_type_indicator(
        kpi: Kpi,
        town_ine: str,
        kpi_reports: List[ReportIndicator],
        date_init: date,
        date_end: date) -> List[ReportIndicator]:

    reports_indexed = {}
    for report in kpi_reports:
        reports_indexed[report.date] = report

    list_of_reports = []
    iteration_date, date_increment = _get_interation_and_increment(date_init, kpi.periodicity)

    while iteration_date <= date_end:
        if iteration_date < date_init:
            iteration_date = iteration_date + date_increment
            continue

        if iteration_date in reports_indexed:
            report_to_append = reports_indexed[iteration_date]
        else:
            report_to_append = ReportIndicator.create_empty(town_ine, kpi.id, iteration_date)

        list_of_reports.append(report_to_append)
        iteration_date = iteration_date + date_increment

    return list_of_reports


def render_reports_of_type_rsu(kpi: Kpi, kpi_reports: List[ReportRsu], date_init: date, date_end: date) -> List[ReportRsu]:

    reports_indexed = {}
    for report in kpi_reports:
        reports_indexed[report.date] = report

    list_of_reports = []
    iteration_date, date_increment = _get_interation_and_increment(date_init, kpi.periodicity)

    while iteration_date <= date_end:
        if iteration_date < date_init:
            iteration_date = iteration_date + date_increment
            continue

        if iteration_date in reports_indexed:
            report_to_append = reports_indexed[iteration_date]
        else:
            report_to_append = ReportRsu.create_empty(kpi.id, iteration_date)

        list_of_reports.append(report_to_append)
        iteration_date = iteration_date + date_increment

    return list_of_reports


def _get_interation_and_increment(date_init: date, periodicity: str) -> Tuple[date, relativedelta]:
    init_year = date_init.year
    init_month = date_init.month
    init_day = date_init.day

    if periodicity == "yearly":
        iteration_date = date(int(init_year), 1, 1)
        date_increment = relativedelta(years=+1)
    elif periodicity == "monthly":
        iteration_date = date(int(init_year), int(init_month), 1)
        date_increment = relativedelta(months=+1)
    elif periodicity == "daily":
        iteration_date = date(int(init_year), int(init_month), int(init_day))
        date_increment = relativedelta(days=+1)
    else:
        raise ValueError("Periodicity not supported")

    return iteration_date, date_increment
