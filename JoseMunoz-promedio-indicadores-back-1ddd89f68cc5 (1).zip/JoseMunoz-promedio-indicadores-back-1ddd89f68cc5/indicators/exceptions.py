
class UnauthorizedError(Exception):
    """User is not authorized to access to this resource"""


class CreateUserAlreadyExistsError(Exception):
    """You are trying to create an user that already exists"""


class UserDoesntExistsError(Exception):
    """The user you are trying to manage doesn't exists"""


class KPIAccessIndicatorsExistError(Exception):
    """ The KPI access to indicator already exists"""


class KPIAccessRsuExistsError(Exception):
    """ The KPI access to indicator already exists"""
