from datetime import datetime, date
from typing import Optional


class ReportIndicator(object):

    def __init__(self,
                 town_ine: str,
                 kpi_id: str,
                 report_date: date,
                 value: Optional[float],
                 user_uuid: Optional[str],
                 insertion_date: Optional[datetime],  # TODO coupled internal object with representation
                 last_update_date: Optional[datetime]  # TODO coupled internal object with representation
                 ):
        self.town_ine = town_ine
        self.kpi_id = kpi_id
        self.date = report_date
        self.value = value
        self.user_uuid = user_uuid
        self.insertion_date = insertion_date
        self.last_update_date = last_update_date

    def to_dict(self):
        return self.__dict__

    def to_public_json(self):
        return {
            'town_ine': self.town_ine,
            'kpi_id': self.kpi_id,
            'date': str(self.date),
            'value': self.value,
            'user_uuid': self.user_uuid,
            'insertion_date': self.insertion_date,
            'last_update_date': self.last_update_date
        }

    @staticmethod
    def create_empty(town_ine, kpi_id, date):
        return ReportIndicator(town_ine, kpi_id, date, None, None, None, None)
