
class KpiAccessIndicator(object):

    def __init__(self, user_uuid, town_ine, kpi_id):
        self.user_uuid = user_uuid
        self.town_ine = town_ine
        self.kpi_id = kpi_id

    def to_dict(self):
        return self.__dict__
