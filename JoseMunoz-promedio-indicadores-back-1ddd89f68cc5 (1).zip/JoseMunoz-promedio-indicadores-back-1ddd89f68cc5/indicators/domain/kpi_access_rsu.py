
class KpiAccessRsu(object):

    def __init__(self, user_uuid, kpi_id):
        self.user_uuid = user_uuid
        self.kpi_id = kpi_id

    def to_dict(self):
        return self.__dict__
