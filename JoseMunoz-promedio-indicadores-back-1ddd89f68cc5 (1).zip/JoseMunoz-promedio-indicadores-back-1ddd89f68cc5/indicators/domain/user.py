
class User(object):

    def __init__(self, uuid, email, name, rol_id, firebase_uid):
        self.uuid = uuid
        self.email = email
        self.name = name
        self.rol_id = rol_id
        self.firebase_uid = firebase_uid

    def to_dict(self):
        return self.__dict__

