from datetime import datetime, date
from typing import Optional


class ReportRsu(object):

    def __init__(self,
                 kpi_id: str,
                 date: date,
                 kg: Optional[float],
                 impropios: Optional[float],
                 user_uuid: Optional[str],
                 insertion_date: datetime,  # TODO coupled internal object with representation
                 last_update_date: datetime  # TODO coupled internal object with representation
                 ):
        self.kpi_id = kpi_id
        self.date = date
        self.kg = kg
        self.impropios = impropios
        self.user_uuid = user_uuid
        self.insertion_date = insertion_date
        self.last_update_date = last_update_date

    def to_dict(self):
        return self.__dict__

    def to_public_json(self):
        return {
            'kpi_id': self.kpi_id,
            'date': str(self.date),
            'kg': self.kg,
            'impropios': self.impropios,
            'user_uuid': self.user_uuid,
            'insertion_date': self.insertion_date,
            'last_update_date': self.last_update_date
        }

    @staticmethod
    def create_empty(kpi_id, date):
        return ReportRsu(kpi_id, date, None, None, None, None, None)
