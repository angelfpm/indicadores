from enum import Enum


class RolType(Enum):
    ADM = "ADM"
    JES = "JES"
    PRO = "PRO"
    OWN = "OWN"


class Rol(object):

    def __init__(self, id, name):
        self.id = id
        self.name = name

    def to_dict(self):
        return self.__dict__
