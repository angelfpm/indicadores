

class Town(object):

    def __init__(self, ine, name):
        super().__init__()
        self.ine = ine
        self.name = name

    def to_dict(self):
        return self.__dict__
