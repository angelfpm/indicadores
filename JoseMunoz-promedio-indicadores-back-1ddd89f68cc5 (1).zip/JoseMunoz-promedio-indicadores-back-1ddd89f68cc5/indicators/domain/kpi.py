
class Kpi(object):

    def __init__(self, id, name, unit_measure, periodicity, kpi_type, subtype, description):
        self.id = id
        self.name = name
        self.unit_measure = unit_measure
        self.periodicity = periodicity
        self.type = kpi_type
        self.subtype = subtype
        self.description = description

    def to_dict(self):
        return self.__dict__
