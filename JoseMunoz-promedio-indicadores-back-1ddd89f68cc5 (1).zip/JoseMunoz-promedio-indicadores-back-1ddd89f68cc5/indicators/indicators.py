import uuid
from datetime import date
from typing import Optional, List

from indicators import render_reports, authorizationManagement
from indicators.authorizationManagement import UserFeatures
from indicators.domain.kpi import Kpi
from indicators.domain.report_indicator import ReportIndicator
from indicators.domain.report_rsu import ReportRsu
from indicators.domain.rol import Rol, RolType
from indicators.domain.town import Town
from indicators.domain.user import User
from indicators.exceptions import CreateUserAlreadyExistsError, UnauthorizedError, UserDoesntExistsError, \
    KPIAccessIndicatorsExistError, KPIAccessRsuExistsError
from indicators.repository import user_repository, rol_repository, town_repository, kpi_repository, reports_repository, \
    user_access_kpi_indicator_repository, user_access_kpi_rsu_repository
from indicators.external.firebase_app import FirebaseApp
from indicators.repository.kpi_repository import KpiType


def get_user_by_firebase_token(token: str) -> Optional[User]:
    user_firebase_uid = FirebaseApp().get_user_uid_by_firebase_token(token)
    if user_firebase_uid is None:
        return None
    return user_repository.get_user_by_firebase_uid(user_firebase_uid)


def get_all_users(request_user) -> List[User]:
    user_access = authorizationManagement.user_has_feature(request_user, UserFeatures.USER_ADMINISTRATION)

    if not user_access:
        raise UnauthorizedError()

    return user_repository.get_all_users()


def get_all_roles(request_user) -> List[Rol]:
    user_access = authorizationManagement.user_has_feature(request_user, UserFeatures.USER_ADMINISTRATION)

    if not user_access:
        raise UnauthorizedError()

    return rol_repository.get_all_roles()


def get_all_towns(request_user: User) -> List[Town]:
    all_kpi_access = authorizationManagement.user_has_feature(request_user, UserFeatures.ALL_KPI_ACCESS)
    if all_kpi_access:
        return town_repository.get_all_towns()

    access_list = user_access_kpi_indicator_repository.get_all_user_access_to_kpi_indicator(request_user.uuid)

    # JOIN made in client. Move to database in case of a need of improved performance.
    unique_town_ine = set()
    for access in access_list:
        unique_town_ine.add(access.town_ine)

    return [town_repository.get_town_by_ine(town_ine) for town_ine in unique_town_ine]


def get_kpi_by_id(request_user: User, kpi_id: str) -> Kpi:
    """
    all_kpi_access = authorizationManagement.user_has_feature(request_user, UserFeatures.ALL_KPI_ACCESS)

    if all_kpi_access:
        return kpi_repository.get_kpi_by_id(kpi_id)

    raise UnauthorizedError()
    """
    return kpi_repository.get_kpi_by_id(kpi_id)


def get_all_kpis(request_user: User) -> List[Kpi]:
    """
    all_kpi_access = authorizationManagement.user_has_feature(request_user, UserFeatures.ALL_KPI_ACCESS)

    if all_kpi_access:
        raise UnauthorizedError()
    """
    return kpi_repository.get_all_kpis()


def get_kpi_by_type_indicator(request_user: User) -> List[Kpi]:
    """
    all_kpi_access = authorizationManagement.user_has_feature(request_user, UserFeatures.ALL_KPI_ACCESS)

    if all_kpi_access:
        raise UnauthorizedError()
    """
    return kpi_repository.get_kpi_by_type(KpiType.INDICADOR)


def get_kpi_indicator_by_town(request_user: User, town_ine: str) -> List[Kpi]:
    all_kpi_access = authorizationManagement.user_has_feature(request_user, UserFeatures.ALL_KPI_ACCESS)

    if all_kpi_access:
        return kpi_repository.get_kpi_by_type(KpiType.INDICADOR)

    access_list = user_access_kpi_indicator_repository.get_all_user_access_by_town(request_user.uuid, town_ine)

    # JOIN made in client. Move to database in case of a need of improved performance.
    unique_kpi_id = set()
    for access in access_list:
        unique_kpi_id.add(access.kpi_id)

    return [kpi_repository.get_kpi_by_id(kpi_id) for kpi_id in unique_kpi_id]


def get_kpi_by_type_rsu(request_user: User) -> List[Kpi]:
    all_kpi_access = authorizationManagement.user_has_feature(request_user, UserFeatures.ALL_KPI_ACCESS)

    if all_kpi_access:
        return kpi_repository.get_kpi_by_type(KpiType.RSU)

    access_list = user_access_kpi_rsu_repository.get_all_user_access_to_kpi_rsu(request_user.uuid)

    print(access_list)

    return [kpi_repository.get_kpi_by_id(access.kpi_id) for access in access_list]


def get_kpi_reports_of_type_rsu(request_user: User, kpi_id: str, date_init: date, date_end: date) -> List[ReportRsu]:
    user_access_feature = authorizationManagement.user_has_feature(request_user, UserFeatures.ALL_KPI_ACCESS)

    user_access_to_kpi = user_access_kpi_rsu_repository.user_has_access_to_kpi_rsu(
        request_user.uuid,
        kpi_id
    )

    if (not user_access_feature) and (not user_access_to_kpi):
        raise UnauthorizedError()

    existing_reports = reports_repository.get_reports_of_type_rsu(kpi_id, date_init, date_end)
    kpi_info = kpi_repository.get_kpi_by_id(kpi_id)
    if kpi_info is None:
        # TODO Log it
        raise ValueError("kpi not found")
    return render_reports.render_reports_of_type_rsu(kpi_info, existing_reports, date_init, date_end)


def get_kpi_reports_of_type_indicator(request_user: User, town_ine: str, kpi_id: str, date_init: date,
                                      date_end: date) -> List[ReportIndicator]:
    user_access_feature = authorizationManagement.user_has_feature(request_user, UserFeatures.ALL_KPI_ACCESS)

    user_access_to_kpi = user_access_kpi_indicator_repository.user_has_access_to_kpi_indicator(
        request_user.uuid,
        town_ine,
        kpi_id
    )

    if (not user_access_feature) and (not user_access_to_kpi):
        raise UnauthorizedError()

    existing_reports = reports_repository.get_reports_of_type_indicators(town_ine, kpi_id, date_init, date_end)

    kpi_info = kpi_repository.get_kpi_by_id(kpi_id)
    if kpi_info is None:
        # TODO Log it
        raise ValueError("kpi not found")
    return render_reports.render_reports_of_type_indicator(kpi_info, town_ine, existing_reports, date_init, date_end)


def create_kpi(request_user: User, new_id, new_name, new_unit_measure, new_periodicity, new_type, new_subtype,
               new_description):
    user_access_feature = authorizationManagement.user_has_feature(request_user, UserFeatures.ALL_KPI_ACCESS)

    if not user_access_feature:
        raise UnauthorizedError()

    if new_type == 'indicador':
        kpi_repository.create_kpi_indicator(
            new_id, new_name, new_unit_measure, new_periodicity, new_type, new_subtype, new_description)
    else:
        kpi_repository.create_kpi_rsu(
            new_id, new_name, new_unit_measure, new_periodicity, new_type, new_description)


def update_kpi(request_user: User, edit_id, edit_name, edit_unit_measure, edit_periodicity, edit_type, edit_subtype,
               edit_description):
    user_access_feature = authorizationManagement.user_has_feature(request_user, UserFeatures.ALL_KPI_ACCESS)

    if not user_access_feature:
        raise UnauthorizedError()

    if edit_type == 'indicador':
        kpi_repository.update_kpi_indicator(
            edit_id, edit_name, edit_unit_measure, edit_periodicity, edit_type, edit_subtype, edit_description)
    else:
        kpi_repository.update_kpi_rsu(
            edit_id, edit_name, edit_unit_measure, edit_periodicity, edit_type, edit_description)


def delete_kpi(request_user: User, kpi_id):
    user_access_feature = authorizationManagement.user_has_feature(request_user, UserFeatures.ALL_KPI_ACCESS)

    if not user_access_feature:
        raise UnauthorizedError()

    kpi_repository.delete_kpi(kpi_id)


def set_report_indicators(request_user: User, town_ine: str, kpi_id: str, report_date: date, value: float):
    """
    user_access = authorizationManagement.user_has_feature(request_user, UserFeatures.ALL_KPI_ACCESS)

    if not user_access:
        raise UnauthorizedError()
    """

    reports_repository.set_report_indicators(town_ine, kpi_id, report_date, value, request_user.uuid)


def set_report_rsu(request_user: User, kpi_id: str, report_date: date, kg: float, impropios: float):
    """
    user_access = authorizationManagement.user_has_feature(request_user, UserFeatures.ALL_KPI_ACCESS)

    if not user_access:
        raise UnauthorizedError()
    """

    reports_repository.set_report_rsu(kpi_id, report_date, kg, impropios, request_user.uuid)


def create_new_user(request_user: User, email: str, password: str, name: str, rol_id: RolType):
    user_access = authorizationManagement.user_has_feature(request_user, UserFeatures.USER_ADMINISTRATION)

    if not user_access:
        raise UnauthorizedError()

    existing_user_in_db = user_repository.get_user_by_email(email)

    if existing_user_in_db is not None:
        raise CreateUserAlreadyExistsError()

    existing_user_in_firebase = FirebaseApp().get_user_by_email(email)
    if existing_user_in_firebase is None:
        existing_user_in_firebase = FirebaseApp().create_firebase_user(email, password, name, rol_id)

    user_repository.create_user(
        uuid.uuid4(),
        email,
        name,
        rol_id,
        existing_user_in_firebase.uid
    )


def delete_user(request_user: User, email: str):
    user_access = authorizationManagement.user_has_feature(request_user, UserFeatures.USER_ADMINISTRATION)

    if not user_access:
        raise UnauthorizedError()

    existing_user_in_db = user_repository.get_user_by_email(email)

    if existing_user_in_db is None:
        raise UserDoesntExistsError()

    user_repository.delete_user(existing_user_in_db.email)
    FirebaseApp().delete_user(existing_user_in_db.firebase_uid)


def edit_user(request_user: User, email: str, password: str, name: str, rol_id: RolType):
    user_access = authorizationManagement.user_has_feature(request_user, UserFeatures.USER_ADMINISTRATION)

    if not user_access:
        raise UnauthorizedError()

    existing_user_in_db = user_repository.get_user_by_email(email)

    if existing_user_in_db is None:
        raise UserDoesntExistsError()

    if existing_user_in_db.name != name:
        user_repository.update_user_name(email, name)

    if existing_user_in_db.rol_id != rol_id.value:
        user_repository.update_user_rol_id(email, rol_id)
        FirebaseApp().update_user_role(existing_user_in_db.firebase_uid, rol_id)

    if password is not None:
        FirebaseApp().update_user_password(existing_user_in_db.firebase_uid, password)


def get_user_info(request_user, user_uuid):
    user_access = authorizationManagement.user_has_feature(request_user, UserFeatures.USER_ADMINISTRATION)

    if not user_access:
        raise UnauthorizedError()

    return user_repository.get_user_by_uuid(user_uuid)


def get_user_kpi_access_indicators(request_user, user_uuid):
    user_access = authorizationManagement.user_has_feature(request_user, UserFeatures.USER_ADMINISTRATION)

    if not user_access:
        raise UnauthorizedError()

    # Probably more efficient with a JOIN to the database.
    # Going this way to not having to add "the hack" in one repository.
    access_list = user_access_kpi_indicator_repository.get_all_user_access_to_kpi_indicator(user_uuid)
    for access in access_list:
        access.town_name = town_repository.get_town_by_ine(access.town_ine).name
        access.kpi_name = kpi_repository.get_kpi_by_id(access.kpi_id).name
    return access_list


def delete_kpi_access_indicators(request_user: User, user_uuid: str, town_ine: str, kpi_id: str):
    user_access = authorizationManagement.user_has_feature(request_user, UserFeatures.USER_ADMINISTRATION)

    if not user_access:
        raise UnauthorizedError()

    return user_access_kpi_indicator_repository.delete_user_access_to_kpi_rsu(user_uuid, town_ine, kpi_id)


def create_kpi_access_indicators(request_user: User, user_uuid: str, town_ine: str, kpi_id: str):
    user_access = authorizationManagement.user_has_feature(request_user, UserFeatures.USER_ADMINISTRATION)

    if not user_access:
        raise UnauthorizedError()

    existing_kpi_access_indicators_in_db = user_access_kpi_indicator_repository \
        .user_has_access_to_kpi_indicator(user_uuid, town_ine, kpi_id)

    if existing_kpi_access_indicators_in_db:
        raise KPIAccessIndicatorsExistError()

    user_access_kpi_indicator_repository \
        .create_user_access_to_kpi_indicator_in_town(user_uuid, town_ine, kpi_id)


def get_user_kpi_access_rsu(request_user, user_uuid):
    user_access = authorizationManagement.user_has_feature(request_user, UserFeatures.USER_ADMINISTRATION)

    if not user_access:
        raise UnauthorizedError()

    # Probably more efficient with a JOIN to the database.
    # Going this way to not having to add "the hack" in one repository.
    access_list = user_access_kpi_rsu_repository.get_all_user_access_to_kpi_rsu(user_uuid)
    for access in access_list:
        access.kpi_name = kpi_repository.get_kpi_by_id(access.kpi_id).name
    return access_list


def delete_kpi_access_rsu(request_user: User, user_uuid: str, kpi_id: str):
    user_access = authorizationManagement.user_has_feature(request_user, UserFeatures.USER_ADMINISTRATION)

    if not user_access:
        raise UnauthorizedError()

    return user_access_kpi_rsu_repository.delete_user_access_to_kpi_rsu(user_uuid, kpi_id)


def create_kpi_access_rsu(request_user: User, user_uuid: str, kpi_id: str):
    user_access = authorizationManagement.user_has_feature(request_user, UserFeatures.USER_ADMINISTRATION)

    if not user_access:
        raise UnauthorizedError()

    existing_kpi_access_rsu_in_db = user_access_kpi_rsu_repository \
        .user_has_access_to_kpi_rsu(user_uuid, kpi_id)

    if existing_kpi_access_rsu_in_db:
        raise KPIAccessRsuExistsError()

    user_access_kpi_rsu_repository \
        .create_user_access_to_kpi_rsu(user_uuid, kpi_id)
