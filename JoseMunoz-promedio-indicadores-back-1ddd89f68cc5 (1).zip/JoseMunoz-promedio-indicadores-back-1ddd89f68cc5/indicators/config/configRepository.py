from enum import Enum

import yaml
import os

FLASK_ENV = 'FLASK_ENV'


class ExecutionEnvironment(Enum):
    DEVELOPMENT = "development"
    DEVELOPMENT_NEXT = "development-next"
    DEVELOPMENT_EXT_DB = "development-ext-db"
    PREPRODUCTION = "preproduction"
    PRODUCTION = "production"


def _get_config_folder_path():
    return {
        ExecutionEnvironment.DEVELOPMENT: "config/development/",
        ExecutionEnvironment.DEVELOPMENT_NEXT: "config/development-next/",
        ExecutionEnvironment.DEVELOPMENT_EXT_DB: "config/development-ext-db/",
        ExecutionEnvironment.PREPRODUCTION: "config/preproduction/",
        ExecutionEnvironment.PRODUCTION: "config/production/"
    }.get(get_actual_environment_type())


def _get_config():
    with open("{}/config.yaml".format(_get_config_folder_path()), 'r') as stream:
        try:
            return yaml.load(stream, Loader=yaml.SafeLoader)
        except yaml.YAMLError as exc:
            pass  # TODO log it


def get_actual_environment_type() -> ExecutionEnvironment:
    if FLASK_ENV in os.environ:
        if os.environ[FLASK_ENV] == ExecutionEnvironment.DEVELOPMENT.value:
            return ExecutionEnvironment.DEVELOPMENT
        if os.environ[FLASK_ENV] == ExecutionEnvironment.DEVELOPMENT_NEXT.value:
            return ExecutionEnvironment.DEVELOPMENT_NEXT
        if os.environ[FLASK_ENV] == ExecutionEnvironment.DEVELOPMENT_EXT_DB.value:
            return ExecutionEnvironment.DEVELOPMENT_EXT_DB
        elif os.environ[FLASK_ENV] == ExecutionEnvironment.PREPRODUCTION.value:
            return ExecutionEnvironment.PREPRODUCTION
    return ExecutionEnvironment.PRODUCTION


def get_mysql_config():
    return _get_config()['mysql']


def get_firebase_config_file_path():
    return "{}/promedio-indicadores-firebase-adminsdk.json".format(_get_config_folder_path())


def get_reporting_security_management_config():
    return _get_config()['reporting_system']['security_management']


def get_reporting_context_broker_config():
    return _get_config()['reporting_system']['context_broker']


def get_reporting_provider_config():
    return _get_config()['reporting_system']['provider_config']
