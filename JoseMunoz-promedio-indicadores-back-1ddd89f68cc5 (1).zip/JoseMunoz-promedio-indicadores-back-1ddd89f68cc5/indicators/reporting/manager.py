import json
from datetime import datetime, date
import datetime as datetime_module
from datetime import timedelta
import time

from indicators.reporting import report_factory, reportRepository
from indicators.reporting.tokenRepository import TokenRepository
from indicators.repository import reports_repository, kpi_repository, town_repository


def send_reports_indicators(token_repository):

    #  All the indicators reports available
    all_indicators_reports = reports_repository.get_all_reports_of_type_indicators()
    for report in all_indicators_reports:

        kpi_info = kpi_repository.get_kpi_by_id(report.kpi_id)
        report_formatted = report_factory.create_report_indicator(
            report.kpi_id,
            kpi_info.name,
            kpi_info.description,
            datetime_to_iso8601(report.insertion_date),  # TODO this is an optional
            date_to_iso8601_with_hack(report.date),
            report.town_ine,
            town_repository.get_town_by_ine(report.town_ine).name,
            kpi_info.periodicity,
            str(report.value)
        )
        reportRepository.send_report(report_formatted, token_repository.get_token())


def send_reports_rsu(token_repository):

    #  All RSU
    all_rsu_reports = reports_repository.get_all_reports_of_type_rsu()
    for report in all_rsu_reports:
        kpi_info = kpi_repository.get_kpi_by_id(report.kpi_id)
        report_formatted = report_factory.create_report_rsu(
            report.kpi_id,
            kpi_info.name,
            kpi_info.description,
            str(report.kg),
            datetime_to_iso8601(report.insertion_date),
            date_to_iso8601_with_hack(report.date),
            kpi_info.periodicity
        )
        reportRepository.send_report(report_formatted, token_repository.get_token())


def datetime_to_iso8601_with_hack(original_date: datetime)-> str:
    hacked_datetime = hack_to_avoid_handling_time_zones_in_fiware___adds_3_hours(original_date)
    return datetime_to_iso8601(hacked_datetime)


def date_to_iso8601_with_hack(original_date: date)-> str:
    new_datetime = datetime.combine(original_date, datetime.min.time())
    hacked_datetime = hack_to_avoid_handling_time_zones_in_fiware___adds_3_hours(new_datetime)
    return datetime_to_iso8601(hacked_datetime)


def hack_to_avoid_handling_time_zones_in_fiware___adds_3_hours(original_date: datetime) -> datetime:
    return original_date + timedelta(hours=3)


def datetime_to_iso8601(original_date: datetime)-> str:
    utc_offset_sec = time.altzone if time.localtime().tm_isdst else time.timezone
    utc_offset = datetime_module.timedelta(seconds=-utc_offset_sec)
    return original_date \
        .replace(microsecond=0) \
        .replace(tzinfo=datetime_module.timezone(offset=utc_offset))\
        .isoformat()


if __name__ == '__main__':
    token_repository = TokenRepository()

    send_reports_indicators(token_repository)
    send_reports_rsu(token_repository)
