import json
import uuid
import requests

from indicators.config import configRepository


def save_to_file(url, headers, request_body):
    filename = str(uuid.uuid4())
    import os
    if not os.path.exists('jsons_generated'):
        os.makedirs('jsons_generated')

    with open('jsons_generated/' + filename + '.json', 'w') as outfile:
        outfile.write('URL:\n')
        outfile.write(url)
        outfile.write('\nHeaders:\n')
        outfile.write(str(headers))
        outfile.write('\nContent:\n')
        outfile.write(request_body)


def send_report(report, token):
    context_broker_config = configRepository.get_reporting_context_broker_config()
    provider_config = configRepository.get_reporting_provider_config()

    url = "http://{0}:{1}/v2/entities".format(
        context_broker_config['ip'],
        context_broker_config['port']
    )
    headers = {
        'Content-Type': 'application/json',
        'Fiware-Service': provider_config['service'],
        'Fiware-ServicePath': provider_config['subservice'],
        'X-Auth-Token': token
    }

    request_body = json.dumps(report, ensure_ascii=False)
    return requests.post(url, headers=headers, data=request_body.encode('utf-8'))  # TODO capture the return value and show it


def update_report(report, token):
    context_broker_config = configRepository.get_reporting_context_broker_config()
    provider_config = configRepository.get_reporting_provider_config()

    url = "http://{0}:{1}/v2/entities".format(
        context_broker_config['ip'],
        context_broker_config['port']
    )
    headers = {
        'Content-Type': 'application/json',
        'Fiware-Service': provider_config['service'],
        'Fiware-ServicePath': provider_config['subservice'],
        'X-Auth-Token': token
    }

    request_body = json.dumps(report, ensure_ascii=False)

    # return requests.post(url, headers=headers, data=request_body)
    save_to_file(url, headers, request_body)

