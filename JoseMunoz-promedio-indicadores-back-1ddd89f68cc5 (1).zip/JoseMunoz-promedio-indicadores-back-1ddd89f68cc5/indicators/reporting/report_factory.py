import datetime


def create_report_indicator(kpi_id, kpi_name, kpi_description, creation_time: datetime, date: datetime, ine, town_name,
                            periodicity, kpi_value):
    result = {
        "id": "kpi_SGI_" + kpi_id,  # Id de la entidad, ejemplo "kpi_SGI_nhabserv"
        "type": "KeyPerformanceIndicator",  # Fijado.
        "dateCreated": {
            "value": creation_time,  # Timestamp de creación. (DateTime)
            "type": "DateTime"  # Fijado
        },
        "dateModified": {
            "value": date,  # Timestamp del la fecha a la que pertenece el reporte
            "type": "DateTime"
        },
        "name": {
            "value": kpi_name,  # Nombre descriptivo del KPI. Ejemplo: " Num_Habitantes_Con_Servicio "
            "type": "Text"
        },
        # Descripción de nombre dato / indicador Attribute type: Text,
        # Ejemplo "Nº de Habitantes con servicio"
        "description": {
            "value": kpi_description,
        },
        "branchCode": {  # Código INE del Municipio. Attribute type: Number
            "value": "{:03d}".format(ine),  # TODO is now a text
            "type": "Text"
        },
        "address": {
            "type": "PostalAddress",
            "value": {
                "addressLocality": town_name  # Nombre municipio al que pertenece este dato.
            }
        },
        "kpiValue": {
            "value": kpi_value
        },
        "calculationMethod": {
            "value": "automatic"
        },
        "calculationFrequency": {
            "value": periodicity
        }
    }
    return result


def create_report_rsu(kpi_id, kpi_name, kpi_description, kg, creation_time: datetime, date: datetime, periodicity):
    return {
        "id": "kpi_SGI_" + kpi_id,  # Id de la entidad, ejemplo "kpi_SGI_nhabserv"
        "type": "KeyPerformanceIndicator",  # Fijado.
        "dateCreated": {
            "value": creation_time,  # Timestamp de creación. (DateTime)
            "type": "DateTime"  # Fijado
        },
        "dateModified": {
            "value": date,  # Timestamp del la fecha a la que pertenece el reporte
            "type": "DateTime"
        },
        "route": {
            "value": kpi_id,
            "type": "Text"
        },
        "name": {
            "value": kpi_name,  # Nombre descriptivo del KPI. Ejemplo: " Num_Habitantes_Con_Servicio "
            "type": "Text"
        },
        "description": {
            "value": kpi_description,
        },
        "kpiValue": {
            "value": kg
        },
        "calculationMethod": {
            "value": "automatic"
        },
        "calculationFrequency": {
            "value": periodicity
        }
    }
