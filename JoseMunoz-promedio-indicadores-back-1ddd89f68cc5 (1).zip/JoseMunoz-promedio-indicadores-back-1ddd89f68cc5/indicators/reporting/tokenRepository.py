import json
from datetime import datetime, timedelta
import requests
from indicators.config import configRepository

TOKEN_VALID_PERIOD = timedelta(minutes=25)


class TokenRepository(object):
    def __init__(self, token_valid_period=TOKEN_VALID_PERIOD):
        self.token = None
        self.token_valid_period = token_valid_period
        self.token_creation_date = None

    def get_token(self):
        if self.token is None:
            self.token = self._get_initial_token()
            self.token_creation_date = datetime.now()
            return self.token

        if datetime.now() - self.token_creation_date > self.token_valid_period:
            self.token = self._get_renovated_token()
            self.token_creation_date = datetime.now()
            return self.token

        return self.token

    def _get_initial_token(self) -> json:
        security_management_config = configRepository.get_reporting_security_management_config()
        provider_config = configRepository.get_reporting_provider_config()

        url = "http://{0}:{1}/v3/auth/tokens".format(
            security_management_config['ip'],
            security_management_config['port']
        )
        headers = {'Content-Type': 'application/json'}
        request_body = json.dumps({
            "auth": {
                "identity": {
                    "methods": [
                        "password"
                    ],
                    "password": {
                        "user": {
                            "domain": {
                                "name": provider_config['service']
                            },
                            "name": provider_config['user'],
                            "password": provider_config['password']
                        }
                    }
                },
                "scope": {
                    "project": {
                        "domain": {
                            "name": provider_config['service']
                        },
                        "name": provider_config['subservice']
                    }
                }
            }
        })

        response = requests.post(url, headers=headers, data=request_body)

        return response.headers['X-Subject-Token']

    def _get_renovated_token(self) -> json:
        security_management_config = configRepository.get_reporting_security_management_config()

        url = "http://{0}:{1}/v3/auth/tokens".format(
            security_management_config['ip'],
            security_management_config['port']
        )
        headers = {'Content-Type': 'application/json'}
        request_body = json.dumps({
            "auth": {
                "identity": {
                     "methods": [
                         "token"
                     ],
                     "token": {
                        "id": self.token
                     }
                }
            }
        })

        response = requests.post(url, headers=headers, data=request_body)
        return response.headers['X-Subject-Token']
