import pymysql

from indicators.config.configRepository import get_mysql_config

mysql_config = get_mysql_config()


class MysqlConnection(object):

    def __init__(self):
        if 'ip' in mysql_config:
            self.connection = pymysql.connect(
                host=mysql_config['ip'],
                user=mysql_config['root_user'],
                password=mysql_config['root_password'],
                db=mysql_config['domain_database'],
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor
            )
        else:
            self.connection = pymysql.connect(
                unix_socket=mysql_config['unix_socket'],
                user=mysql_config['root_user'],
                password=mysql_config['root_password'],
                db=mysql_config['domain_database'],
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor
            )

    def get_connection(self):
        return self.connection
