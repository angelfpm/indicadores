from typing import Optional

import firebase_admin
from firebase_admin import auth
from firebase_admin.auth import UserRecord

from indicators.config.configRepository import get_actual_environment_type, ExecutionEnvironment, \
    get_firebase_config_file_path
from indicators.domain.rol import RolType

cred = firebase_admin.credentials.Certificate(get_firebase_config_file_path())


class FirebaseApp(object):

    def __init__(self):

        try:
            firebase_admin.get_app()
        except ValueError:
            firebase_admin.initialize_app(cred, None)
        pass

    def get_user_uid_by_firebase_token(self, auth_token) -> Optional[str]:

        # TODO change this to something better
        if get_actual_environment_type() == ExecutionEnvironment.DEVELOPMENT and auth_token == "jmunozkr":
            return "E5d8PezPRscGtRabzqHWQlgPRMB3"

        if auth_token == '' or auth_token is None:
            return None

        try:
            decoded_token = firebase_admin.auth.verify_id_token(auth_token)
            return decoded_token['uid']
        except:
            # TODO log errors
            return None

    def get_user_by_email(self, email: str) -> Optional[UserRecord]:
        try:
            return firebase_admin.auth.get_user_by_email(email)
        except firebase_admin.auth.AuthError:
            return None

    def create_firebase_user(self, email: str, password: str, name: str, rol_id: RolType) -> UserRecord:
        new_user = firebase_admin.auth.create_user(
            email=email,
            password=password,
            display_name=name,
            email_verified=True,
        )

        self.update_user_role(new_user.uid, rol_id)

        return new_user

    def update_user_role(self, firebase_uid: str, rol_id: RolType):
        if rol_id == RolType.OWN:
            auth.set_custom_user_claims(firebase_uid, {"OWN": True})
        else:
            auth.set_custom_user_claims(firebase_uid, None)

    def update_user_password(self, firebase_uid: str, password: str):
        firebase_admin.auth.update_user(
            firebase_uid,
            password=password
        )

    def delete_user(self, firebase_uid: str):
        firebase_admin.auth.delete_user(firebase_uid)
