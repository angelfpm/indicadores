from indicators.domain.kpi_access_indicators import KpiAccessIndicator
from indicators.external.mysql_connection import MysqlConnection
from typing import List


def user_has_access_to_kpi_indicator(user_uuid: str, town_ine: str, kpi_id: str) -> bool:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    data_to_be_inserted = {
        'user_uuid': user_uuid,
        'town_ine': town_ine,
        'kpi_id': kpi_id,
    }

    sql = """
      SELECT count(*)
      FROM user_access_to_kpi_indicator
      WHERE 
        user_uuid = %(user_uuid)s AND
        town_ine = %(town_ine)s AND
        kpi_id = %(kpi_id)s
        """
    cursor.execute(sql, data_to_be_inserted)
    result = cursor.fetchone()['count(*)']

    connection.commit()
    cursor.close()
    return result == 1


def get_all_user_access_to_kpi_indicator(user_uuid: str) -> List[KpiAccessIndicator]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = """
      SELECT *
      FROM user_access_to_kpi_indicator
      WHERE 
        user_uuid = %s
        """
    cursor.execute(sql, (user_uuid,))
    results = cursor.fetchall()

    connection.commit()
    cursor.close()
    return [KpiAccessIndicator(access['user_uuid'], access['town_ine'], access['kpi_id']) for access in results]


def get_all_user_access_by_town(user_uuid: str, town_ine: str) -> List[KpiAccessIndicator]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    data_to_be_selected = {
        'user_uuid': user_uuid,
        'town_ine': town_ine
    }

    sql = """
      SELECT *
      FROM user_access_to_kpi_indicator
      WHERE 
        user_uuid = %(user_uuid)s AND
        town_ine = %(town_ine)s
        """
    cursor.execute(sql, data_to_be_selected)
    results = cursor.fetchall()

    connection.commit()
    cursor.close()
    return [KpiAccessIndicator(access['user_uuid'], access['town_ine'], access['kpi_id']) for access in results]


def create_user_access_to_kpi_indicator_in_town(user_uuid: str, town_ine: str, kpi_id: str):
    data_to_be_inserted = {
        'user_uuid': user_uuid,
        'town_ine': town_ine,
        'kpi_id': kpi_id,
    }

    _execute_sql("""
        INSERT INTO user_access_to_kpi_indicator (user_uuid, town_ine, kpi_id) 
        VALUES (%(user_uuid)s, %(town_ine)s, %(kpi_id)s)
        """, data_to_be_inserted)


def delete_user_access_to_kpi_rsu(user_uuid, town_ine, kpi_id):
    data_to_be_removed = {
        'user_uuid': user_uuid,
        'town_ine': town_ine,
        'kpi_id': kpi_id
    }

    _execute_sql("""
          DELETE FROM user_access_to_kpi_indicator
          WHERE user_uuid = %(user_uuid)s AND town_ine = %(town_ine)s AND kpi_id = %(kpi_id)s
          """, data_to_be_removed)


def _execute_sql(sql, data):  # TODO move to helper
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    cursor.execute(sql, data)

    connection.commit()
    cursor.close()

    return None

