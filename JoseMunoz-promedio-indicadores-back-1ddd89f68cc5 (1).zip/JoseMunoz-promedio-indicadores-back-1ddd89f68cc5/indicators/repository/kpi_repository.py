from typing import List, Optional

from indicators.domain.kpi import Kpi
from indicators.external.mysql_connection import MysqlConnection
from enum import Enum


class KpiType(Enum):  # TODO Move to domain object
    RSU = "rsu"
    INDICADOR = "indicador"


class KpiSubType(Enum):
    INDICADOR_DEPURACION = "depuracion"
    INDICADOR_RSU = "rsu"
    INDICADOR_AGUA_POTABLE = "agua_potable"


def get_all_kpis() -> List[Kpi]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM kpi"
    cursor.execute(sql)
    results = cursor.fetchall()

    connection.commit()
    cursor.close()
    return [Kpi(kpi['id'],
                kpi['name'],
                kpi['unit_measure'],
                kpi['periodicity'],
                kpi['type'],
                kpi['subtype'],
                kpi['description']
                ) for kpi in results]


def get_kpi_by_id(kpi_id: str) -> Optional[Kpi]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM kpi WHERE id = %s"
    cursor.execute(sql, (kpi_id,))
    kpi = cursor.fetchone()

    connection.commit()
    cursor.close()
    if kpi is None:
        return None
    else:
        return Kpi(kpi['id'],
                   kpi['name'],
                   kpi['unit_measure'],
                   kpi['periodicity'],
                   kpi['type'],
                   kpi['subtype'],
                   kpi['description']
                   )


def get_kpi_by_type(kpi_type: KpiType) -> List[Kpi]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM kpi WHERE type = %s"
    cursor.execute(sql, (kpi_type.value,))
    results = cursor.fetchall()

    connection.commit()
    cursor.close()
    return [Kpi(kpi['id'],
                kpi['name'],
                kpi['unit_measure'],
                kpi['periodicity'],
                kpi['type'],
                kpi['subtype'],
                kpi['description']
                ) for kpi in results]


def create_kpi_indicator(id, name, unit_measure, periodicity, type, subtype, description):
    data_to_be_inserted = {
        'id': id,
        'name': name,
        'unit_measure': unit_measure,
        'periodicity': periodicity,
        'type': type,
        'subtype': subtype,
        'description': description
    }

    _execute_sql("""
          INSERT INTO kpi (id, name, unit_measure, periodicity, type, subtype, description)
          VALUES(%(id)s, %(name)s, %(unit_measure)s, %(periodicity)s, %(type)s, %(subtype)s, %(description)s)
          """, data_to_be_inserted)


def create_kpi_rsu(id, name, unit_measure, periodicity, type, description):
    data_to_be_inserted = {
        'id': id,
        'name': name,
        'unit_measure': unit_measure,
        'periodicity': periodicity,
        'type': type,
        'description': description
    }

    _execute_sql("""
          INSERT INTO kpi (id, name, unit_measure, periodicity, type, description)
          VALUES(%(id)s, %(name)s, %(unit_measure)s, %(periodicity)s, %(type)s, %(description)s)
          """, data_to_be_inserted)


def delete_kpi(kpi_id: str):
    _execute_sql("""
          DELETE FROM kpi
          WHERE id = %s
          """, (kpi_id,))


def update_kpi_indicator(id, name, unit_measure, periodicity, type, subtype, description):

    data_to_be_inserted = {
        'id': id,
        'name': name,
        'unit_measure': unit_measure,
        'periodicity': periodicity,
        'type': type,
        'subtype': subtype,
        'description': description
    }

    _execute_sql("""
          UPDATE kpi
          SET name =  %(name)s,
          unit_measure =  %(unit_measure)s,
          periodicity = %(periodicity)s,
          type = %(type)s,
          subtype = %(subtype)s,
          description = %(description)s
          WHERE id =  %(id)s
          """, data_to_be_inserted)


def update_kpi_rsu(id, name, unit_measure, periodicity, type, description):
    data_to_be_inserted = {
        'id': id,
        'name': name,
        'unit_measure': unit_measure,
        'periodicity': periodicity,
        'type': type,
        'description': description
    }

    _execute_sql("""
          UPDATE kpi
          SET name =  %(name)s,
          unit_measure =  %(unit_measure)s,
          periodicity = %(periodicity)s,
          type = %(type)s,
          subtype = NULL,
          description = %(description)s
          WHERE id =  %(id)s
          """, data_to_be_inserted)


def _execute_sql(sql, data):  # TODO move to helper
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    cursor.execute(sql, data)

    connection.commit()
    cursor.close()

    return None
