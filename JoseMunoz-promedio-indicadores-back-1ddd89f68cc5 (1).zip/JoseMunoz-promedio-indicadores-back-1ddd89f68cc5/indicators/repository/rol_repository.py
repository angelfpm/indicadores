from typing import List

from indicators.domain.rol import Rol
from indicators.external.mysql_connection import MysqlConnection


def get_all_roles() -> List[Rol]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM rol"
    cursor.execute(sql)
    results = cursor.fetchall()

    connection.commit()
    cursor.close()

    return [Rol(rol['id'], rol['name']) for rol in results]
