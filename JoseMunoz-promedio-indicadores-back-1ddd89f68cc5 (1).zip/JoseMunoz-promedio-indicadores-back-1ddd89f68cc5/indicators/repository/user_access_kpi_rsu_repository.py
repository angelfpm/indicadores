from typing import List

from indicators.domain.kpi_access_rsu import KpiAccessRsu
from indicators.external.mysql_connection import MysqlConnection


def user_has_access_to_kpi_rsu(user_uuid: str, kpi_id: str) -> bool:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    data_to_be_inserted = {
        'user_uuid': user_uuid,
        'kpi_id': kpi_id,
    }

    sql = """
      SELECT count(*)
      FROM user_access_to_kpi_rsu
      WHERE 
        user_uuid = %(user_uuid)s AND
        kpi_id = %(kpi_id)s
        """
    cursor.execute(sql, data_to_be_inserted)
    result = cursor.fetchone()['count(*)']

    connection.commit()
    cursor.close()
    return result == 1


def get_all_user_access_to_kpi_rsu(user_uuid: str) -> List[KpiAccessRsu]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = """
      SELECT *
      FROM user_access_to_kpi_rsu
      WHERE 
        user_uuid = %s
        """
    cursor.execute(sql, (user_uuid,))
    results = cursor.fetchall()

    connection.commit()
    cursor.close()
    return [KpiAccessRsu(access['user_uuid'], access['kpi_id']) for access in results]


def create_user_access_to_kpi_rsu(user_uuid: str, kpi_id: str):
    data_to_be_inserted = {
        'user_uuid': user_uuid,
        'kpi_id': kpi_id,
    }

    _execute_sql("""
        INSERT INTO user_access_to_kpi_rsu (user_uuid, kpi_id) 
        VALUES (%(user_uuid)s, %(kpi_id)s)
        """, data_to_be_inserted)


def delete_user_access_to_kpi_rsu(user_uuid, kpi_id):
    data_to_be_removed = {
        'user_uuid': user_uuid,
        'kpi_id': kpi_id
    }

    _execute_sql("""
          DELETE FROM user_access_to_kpi_rsu
          WHERE user_uuid = %(user_uuid)s AND kpi_id = %(kpi_id)s
          """, data_to_be_removed)


def _execute_sql(sql, data):  # TODO move to helper
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    cursor.execute(sql, data)

    connection.commit()
    cursor.close()

    return None