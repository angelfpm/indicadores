from datetime import datetime
from typing import List

from indicators.domain.report_indicator import ReportIndicator
from indicators.domain.report_rsu import ReportRsu
from indicators.external.mysql_connection import MysqlConnection


def get_all_reports_of_type_indicators() -> List[ReportIndicator]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = """
          SELECT *
          FROM report
          """

    cursor.execute(sql)
    reports = cursor.fetchall()

    connection.commit()
    cursor.close()

    return [ReportIndicator(
        report['town_ine'],
        report['kpi_id'],
        report['date'],
        report['value'],
        report['user_uuid'],
        report['insertion_date'],
        report['last_update_date']
    ) for report in reports]


def get_all_reports_of_type_rsu() -> List[ReportRsu]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = """
          SELECT *
          FROM report_rsu
          """

    cursor.execute(sql)
    reports = cursor.fetchall()

    connection.commit()
    cursor.close()
    return [ReportRsu(
        report['kpi_id'],
        report['date'],
        report['kg'],
        report['impropios'],
        report['user_uuid'],
        report['insertion_date'],
        report['last_update_date']
    ) for report in reports]


def get_reports_of_type_indicators(town_id, kpi_id, date_init, date_end) -> List[ReportIndicator]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = """
          SELECT *
          FROM report
          WHERE town_ine = %s AND kpi_id = %s AND date >= %s AND date <= %s
          """

    cursor.execute(sql, (town_id, kpi_id, date_init, date_end,))
    reports = cursor.fetchall()

    connection.commit()
    cursor.close()

    return [ReportIndicator(
        report['town_ine'],
        report['kpi_id'],
        report['date'],
        report['value'],
        report['user_uuid'],
        report['insertion_date'],
        report['last_update_date']
    ) for report in reports]


def get_reports_of_type_rsu(kpi_id, date_init, date_end) -> List[ReportRsu]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = """
          SELECT *
          FROM report_rsu
          WHERE kpi_id = %s AND date >= %s AND date <= %s
          """

    cursor.execute(sql, (kpi_id, date_init, date_end,))
    reports = cursor.fetchall()

    connection.commit()
    cursor.close()
    return [ReportRsu(
        report['kpi_id'],
        report['date'],
        report['kg'],
        report['impropios'],
        report['user_uuid'],
        report['insertion_date'],
        report['last_update_date']
    ) for report in reports]


def set_report_indicators(town_ine, kpi_id, report_date, value, user_uuid):
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = """
    INSERT INTO report (town_ine, kpi_id, date, value, user_uuid, insertion_date, last_update_date) 
    VALUES (%(town_ine)s, %(kpi_id)s, %(date)s, %(value)s, %(user_uuid)s, %(insertion_date)s, %(last_update_date)s)
    ON DUPLICATE KEY UPDATE
        value = %(value)s,
        user_uuid = %(user_uuid)s,
        last_update_date = %(last_update_date)s

    """

    data_to_be_inserted = {
        'town_ine': town_ine,
        'kpi_id': kpi_id,
        'date': report_date,
        'value': value,
        'user_uuid': user_uuid,
        'insertion_date': datetime.now(),
        'last_update_date': datetime.now(),
    }
    cursor.execute(sql, data_to_be_inserted)

    connection.commit()
    cursor.close()

    return None


def set_report_rsu(kpi_id, report_date, kg, impropios, user_uuid):
    data_to_be_inserted = {
        'kpi_id': kpi_id,
        'date': report_date,
        'kg': kg,
        'impropios': impropios,
        'user_uuid': user_uuid,
        'insertion_date': datetime.now(),
        'last_update_date': datetime.now(),
    }

    if kg != 'undefined':
        _execute_sql("""
            INSERT INTO report_rsu (kpi_id, date, kg, user_uuid, insertion_date, last_update_date) 
            VALUES (%(kpi_id)s, %(date)s, %(kg)s, %(user_uuid)s, %(insertion_date)s, %(last_update_date)s)
            ON DUPLICATE KEY UPDATE
                kg = %(kg)s,
                user_uuid = %(user_uuid)s,
                last_update_date = %(last_update_date)s

            """, data_to_be_inserted)

    if impropios != 'undefined':
        _execute_sql("""
            INSERT INTO report_rsu (kpi_id, date, impropios, user_uuid, insertion_date, last_update_date) 
            VALUES (%(kpi_id)s, %(date)s, %(impropios)s, %(user_uuid)s, %(insertion_date)s, %(last_update_date)s)
            ON DUPLICATE KEY UPDATE
                impropios = %(impropios)s,
                user_uuid = %(user_uuid)s,
                last_update_date = %(last_update_date)s

            """, data_to_be_inserted)

    return None


def _execute_sql(sql, data):  # TODO move to helper
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    cursor.execute(sql, data)

    connection.commit()
    cursor.close()

    return None
