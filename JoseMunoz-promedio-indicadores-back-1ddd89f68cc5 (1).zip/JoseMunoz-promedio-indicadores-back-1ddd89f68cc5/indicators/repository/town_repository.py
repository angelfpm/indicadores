from typing import List, Optional

from indicators.domain.town import Town
from indicators.external.mysql_connection import MysqlConnection


def get_all_towns() -> List[Town]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM town"
    cursor.execute(sql)
    results = cursor.fetchall()

    connection.commit()
    cursor.close()
    return [Town(town['ine'], town['name']) for town in results]


def get_town_by_ine(ine: str) -> Optional[Town]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = "SELECT * FROM town WHERE ine = %s"
    cursor.execute(sql, (ine,))
    town = cursor.fetchone()

    connection.commit()
    cursor.close()
    if town is None:
        return None
    else:
        return Town(town['ine'], town['name'])
