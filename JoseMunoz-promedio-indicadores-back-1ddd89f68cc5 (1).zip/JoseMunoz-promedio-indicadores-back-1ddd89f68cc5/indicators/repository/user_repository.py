from typing import Optional
from uuid import UUID

from indicators.domain.rol import RolType
from indicators.domain.user import User
from indicators.external.mysql_connection import MysqlConnection


def get_all_users():
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = "SELECT uuid, email, name, rol_id, firebase_uid FROM user"
    cursor.execute(sql)
    results = cursor.fetchall()

    connection.commit()
    cursor.close()
    return results


def get_user_by_firebase_uid(firebase_uid) -> Optional[User]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = """
          SELECT uuid, email, name, rol_id, firebase_uid
          FROM user
          WHERE firebase_uid = %s
          """

    cursor.execute(sql, (firebase_uid,))
    result = cursor.fetchone()

    connection.commit()
    cursor.close()
    if result is not None:
        return User(result['uuid'],
                    result['email'],
                    result['name'],
                    result['rol_id'],
                    result['firebase_uid']
                    )
    else:
        return None


def get_user_by_email(email: str) -> Optional[User]:
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = """
          SELECT uuid, email, name, rol_id, firebase_uid
          FROM user
          WHERE email = %s
          """

    cursor.execute(sql, (email,))
    result = cursor.fetchone()

    connection.commit()
    cursor.close()
    if result is not None:
        return User(result['uuid'],
                    result['email'],
                    result['name'],
                    result['rol_id'],
                    result['firebase_uid']
                    )
    else:
        return None


def get_user_by_uuid(user_uuid):
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    sql = """
          SELECT uuid, email, name, rol_id, firebase_uid
          FROM user
          WHERE uuid = %s
          """

    cursor.execute(sql, (user_uuid,))
    result = cursor.fetchone()

    connection.commit()
    cursor.close()
    if result is not None:
        return User(result['uuid'],
                    result['email'],
                    result['name'],
                    result['rol_id'],
                    result['firebase_uid']
                    )
    else:
        return None


def create_user(uuid: UUID, email: str, name: str, rol_id: RolType, firebase_uid: str):

    data_to_be_inserted = {
        'uuid': str(uuid),
        'email': email,
        'name': name,
        'rol_id': rol_id.value,
        'firebase_uid': firebase_uid
    }

    _execute_sql("""
          INSERT INTO user (uuid, email, name, rol_id, firebase_uid)
          VALUES(%(uuid)s, %(email)s, %(name)s, %(rol_id)s, %(firebase_uid)s)
          """, data_to_be_inserted)


def delete_user(email: str):

    _execute_sql("""
          DELETE FROM user
          WHERE email = %s
          """, (email,))


def update_user_name(email: str, name: str):

    _execute_sql("""
          UPDATE user
          SET name =  %s
          WHERE email =  %s
          """, (name, email, ))


def update_user_rol_id(email: str, rol_id: RolType):
    _execute_sql("""
          UPDATE user
          SET rol_id =  %s
          WHERE email =  %s
          """, (rol_id.value, email, ))


def _execute_sql(sql, data):  # TODO move to helper
    connection = MysqlConnection().get_connection()
    cursor = connection.cursor()

    cursor.execute(sql, data)

    connection.commit()
    cursor.close()

    return None
