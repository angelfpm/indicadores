import math
import traceback
from flask import Blueprint, request, jsonify

from indicators import indicators
from dateutil import parser

from indicators.domain.rol import RolType
from indicators.exceptions import CreateUserAlreadyExistsError, KPIAccessIndicatorsExistError, KPIAccessRsuExistsError, \
    UnauthorizedError

routes = Blueprint('routes', __name__)


@routes.route('/')
def hello_world():
    return 'Promedio Indicadores API'


@routes.route('/api/users', methods=['GET'])
def get_users():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "users not found"}), 401
    return jsonify({"users": indicators.get_all_users(user)})


@routes.route('/api/user', methods=['POST'])
def post_user():
    request_user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if request_user is None:
        return jsonify({"error": 401, "text": "users not found"}), 401

    email = request.args.get('email')
    password = request.args.get('password')
    name = request.args.get('name')  # TODO Validate
    rol_id = RolType[request.args.get('rol_id')]

    try:
        indicators.create_new_user(request_user, email, password, name, rol_id)
        return jsonify({
            "report": "OK"
        }), 200

    except CreateUserAlreadyExistsError:
        return jsonify({"error": 400, "definedErr": "CreateUserAlreadyExistsError", "text": "User already exists"}), 404
    except:
        traceback.print_exc()
        return jsonify({"error": 401, "text": "user creation error"}), 401


@routes.route('/api/user', methods=['DELETE'])
def delete_user():
    request_user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if request_user is None:
        return jsonify({"error": 401, "text": "users not found"}), 401

    email = request.args.get('email')  # TODO VALIDATE

    try:
        indicators.delete_user(request_user, email)
        return jsonify({
            "report": "OK"
        }), 200
    except:
        traceback.print_exc()
        return jsonify({"error": 401, "text": "user deletion error"}), 401


@routes.route('/api/user', methods=['PUT'])
def update_user():
    request_user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if request_user is None:
        return jsonify({"error": 401, "text": "users not found"}), 401

    email = request.args.get('email')  # TODO VALIDATE
    password = request.args.get('password')
    name = request.args.get('name')
    rol_id = RolType[request.args.get('rol_id')]

    try:
        indicators.edit_user(request_user, email, password, name, rol_id)
        return jsonify({
            "report": "OK"
        }), 200
    except:
        traceback.print_exc()
        return jsonify({"error": 401, "text": "user creation error"}), 401


@routes.route('/api/user/<user_uuid>', methods=['GET'])
def get_user_info(user_uuid):
    request_user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if request_user is None:
        return jsonify({"error": 401, "text": "User info not found"}), 401
    user_info = indicators.get_user_info(request_user, user_uuid)
    return jsonify({"user": user_info.to_dict()}), 200


@routes.route('/api/user/<user_uuid>/kpiaccessindicators', methods=['GET'])
def get_user_kpi_access_indicators(user_uuid):
    request_user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if request_user is None:
        return jsonify({"error": 401, "text": "users info not found"}), 401
    kpi_access_info = indicators.get_user_kpi_access_indicators(request_user, user_uuid)
    return jsonify({"access": [kpi_access.to_dict() for kpi_access in kpi_access_info]}), 200


@routes.route('/api/user/<user_uuid>/kpiaccessindicators', methods=['POST'])
def create_user_kpi_access_indicators(user_uuid):
    request_user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if request_user is None:
        return jsonify({"error": 401, "text": "users not found"}), 401

    town_ine = request.args.get('townIne')  # TODO VALIDATE
    kpi_id = request.args.get('kpiId')  # TODO VALIDATE

    try:
        indicators.create_kpi_access_indicators(request_user, user_uuid, town_ine, kpi_id)
        return jsonify({
            "report": "OK"
        }), 200
    except KPIAccessIndicatorsExistError:
        return jsonify(
            {"error": 400, "definedErr": "KPIAccessIndicatorExistsError", "text": "kpi access already exists"}), 404
    except:
        traceback.print_exc()
        return jsonify({"error": 401, "text": "kpi access indicators creation error"}), 401


@routes.route('/api/user/<user_uuid>/kpiaccessindicators', methods=['DELETE'])
def delete_user_kpi_access_indicators(user_uuid):
    request_user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if request_user is None:
        return jsonify({"error": 401, "text": "users not found"}), 401

    town_ine = request.args.get('townIne')  # TODO VALIDATE
    kpi_id = request.args.get('kpiId')  # TODO VALIDATE

    try:
        indicators.delete_kpi_access_indicators(request_user, user_uuid, town_ine, kpi_id)
        return jsonify({
            "report": "OK"
        }), 200
    except:
        traceback.print_exc()
        return jsonify({"error": 401, "text": "kpi access indicators deletion error"}), 401


@routes.route('/api/user/<user_uuid>/kpiaccessrsu', methods=['GET'])
def get_user_kpi_access_rsu(user_uuid):
    request_user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if request_user is None:
        return jsonify({"error": 401, "text": "User info not found"}), 401
    kpi_access_info = indicators.get_user_kpi_access_rsu(request_user, user_uuid)
    return jsonify({"access": [kpi_access.to_dict() for kpi_access in kpi_access_info]}), 200


@routes.route('/api/user/<user_uuid>/kpiaccessrsu', methods=['POST'])
def create_user_kpi_access_rsu(user_uuid):
    request_user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if request_user is None:
        return jsonify({"error": 401, "text": "users not found"}), 401

    kpi_id = request.args.get('kpiId')  # TODO VALIDATE

    try:
        indicators.create_kpi_access_rsu(request_user, user_uuid, kpi_id)
        return jsonify({
            "report": "OK"
        }), 200
    except KPIAccessRsuExistsError:
        return jsonify(
            {"error": 404, "definedErr": "KPIAccessRsuExistsError", "text": "kpi access rsu already exists"}), 404
    except:
        traceback.print_exc()
        return jsonify({"error": 401, "text": "kpi access rsu creation error"}), 401


@routes.route('/api/user/<user_uuid>/kpiaccessrsu', methods=['DELETE'])
def delete_user_kpi_access_rsu(user_uuid):
    request_user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if request_user is None:
        return jsonify({"error": 401, "text": "users not found"}), 401

    kpi_id = request.args.get('kpiId')  # TODO VALIDATE

    try:
        indicators.delete_kpi_access_rsu(request_user, user_uuid, kpi_id)
        return jsonify({
            "report": "OK"
        }), 200
    except:
        traceback.print_exc()
        return jsonify({"error": 401, "text": "kpi access rsu deletion error"}), 401


@routes.route('/api/getOwnUserInfo', methods=['GET'])
def get_own_user_info():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "User info not found"}), 401

    return jsonify({"user": user.to_dict()}), 200


@routes.route('/api/roles', methods=['GET'])
def get_roles():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "roles not found"}), 401
    return jsonify({"roles:": [rol.to_dict() for rol in indicators.get_all_roles(user)]})


@routes.route('/api/towns', methods=['GET'])
def get_towns():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "towns not found"}), 401
    towns = indicators.get_all_towns(user)
    return jsonify({"towns": [town.to_dict() for town in towns]})


@routes.route('/api/kpi', methods=['GET'])
def get_kpi_by_id():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "kpis not found"}), 401
    kpi_id = request.args.get('kpi_id')
    kpi = indicators.get_kpi_by_id(user, kpi_id)
    return jsonify({"kpi": kpi.to_dict()})


@routes.route('/api/kpi', methods=['POST'])
def create_kpi():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "kpis not found"}), 401

    new_id = request.args.get('newId')
    new_name = request.args.get('newName')
    new_unit_measure = request.args.get('newUnitMeasure')
    new_periodicity = request.args.get('newPeriodicity')
    new_type = request.args.get('newType')
    new_subtype = request.args.get('newSubtype')
    new_description = request.args.get('newDescription')

    try:
        indicators.create_kpi(user, new_id, new_name, new_unit_measure, new_periodicity, new_type, new_subtype,
                              new_description)
        return jsonify({
            "report": "OK"
        }), 200

    except:
        traceback.print_exc()
        return jsonify({"error": 404, "text": "Kpi edition error"}), 404


@routes.route('/api/kpi', methods=['PUT'])
def update_kpi():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "kpis not found"}), 401

    edit_id = request.args.get('editId')
    edit_name = request.args.get('editName')
    edit_unit_measure = request.args.get('editUnitMeasure')
    edit_periodicity = request.args.get('editPeriodicity')
    edit_type = request.args.get('editType')
    edit_subtype = request.args.get('editSubtype')
    edit_description = request.args.get('editDescription')

    try:
        indicators.update_kpi(user, edit_id, edit_name, edit_unit_measure, edit_periodicity, edit_type, edit_subtype,
                              edit_description)
        return jsonify({
            "report": "OK"
        }), 200

    except:
        traceback.print_exc()
        return jsonify({"error": 404, "text": "Kpi edition error"}), 404


@routes.route('/api/kpi', methods=['DELETE'])
def delete_kpi():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "kpis not found"}), 401

    kpi_id = request.args.get('kpiId')

    try:
        indicators.delete_kpi(user, kpi_id)
        return jsonify({
            "report": "OK"
        }), 200
    except:
        traceback.print_exc()
        return jsonify({"error": 401, "text": "kpi deletion error"}), 401


@routes.route('/api/kpis', methods=['GET'])
def get_kpis():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "kpis not found"}), 401
    kpis = indicators.get_all_kpis(user)
    return jsonify({"kpis": [kpi.to_dict() for kpi in kpis]})


@routes.route('/api/kpisIndicators', methods=['GET'])
def get_kpis_by_type_indicator():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "kpis not found"}), 401

    kpis = indicators.get_kpi_by_type_indicator(user)
    return jsonify({"kpis": [kpi.to_dict() for kpi in kpis]})


@routes.route('/api/kpisIndicatorsByTown', methods=['GET'])
def get_kpis_by_type_indicator_by_town():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "kpis not found"}), 401

    town_ine = request.args.get('town_ine')

    kpis = indicators.get_kpi_indicator_by_town(user, town_ine)
    return jsonify({"kpis": [kpi.to_dict() for kpi in kpis]})


@routes.route('/api/kpisRSU', methods=['GET'])
def get_kpis_by_type_rsu():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "kpis not found"}), 401
    kpis = indicators.get_kpi_by_type_rsu(user)
    return jsonify({"kpis": [kpi.to_dict() for kpi in kpis]})


@routes.route('/api/getKpiReportsIndicators', methods=['GET'])
def get_kpi_reports_indicators():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "kpi reports not found"}), 401

    date_init = parser.parse(request.args.get('date_init')).date()
    date_end = parser.parse(request.args.get('date_end')).date()
    town_ine = request.args.get('town_ine')
    kpi_id = request.args.get('kpi_id')

    try:
        reports = indicators.get_kpi_reports_of_type_indicator(user, town_ine, kpi_id, date_init, date_end)
        return jsonify({
            "kpi_reports": [report.to_public_json() for report in reports]
        }), 200

    except:
        traceback.print_exc()
        return jsonify({"error": 404, "text": "kpi reports error"}), 404


@routes.route('/api/getKpiReportsRsu', methods=['GET'])
def get_kpi_reports_rsu():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "kpi reports not found"}), 401

    date_init = parser.parse(request.args.get('date_init')).date()
    date_end = parser.parse(request.args.get('date_end')).date()
    kpi_id = request.args.get('kpi_id')

    try:
        reports = indicators.get_kpi_reports_of_type_rsu(user, kpi_id, date_init, date_end)
        return jsonify({
            "kpi_reports": [report.to_public_json() for report in reports]
        }), 200

    except:
        traceback.print_exc()
        return jsonify({"error": 404, "text": "kpi reports error"}), 404


@routes.route('/api/reportIndicator', methods=['POST'])
def post_report():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "kpi reports not found"}), 401

    date = parser.parse(request.args.get('date')).date()
    value = _float_or_none(request.args.get('value'))
    town_ine = request.args.get('town_ine')
    kpi_id = request.args.get('kpi_id')

    try:
        indicators.set_report_indicators(user, town_ine, kpi_id, date, value)
        return jsonify({
            "report": "OK"
        }), 200

    except:
        traceback.print_exc()
        return jsonify({"error": 404, "text": "report error"}), 404


@routes.route('/api/reportRsu', methods=['POST'])
def post_report_rsu():
    user = indicators.get_user_by_firebase_token(_get_auth_token(request))
    if user is None:
        return jsonify({"error": 401, "text": "kpi reports not found"}), 401

    kpi_id = request.args.get('kpi_id')
    date = parser.parse(request.args.get('date')).date()
    kg = _float_or_none(request.args.get('kg'))
    impropios = _float_or_none(request.args.get('impropios'))

    try:
        indicators.set_report_rsu(user, kpi_id, date, kg, impropios)
        return jsonify({
            "report": "OK"
        }), 200

    except:
        traceback.print_exc()
        return jsonify({"error": 404, "text": "report error"}), 404


def _float_or_none(unknow_data):
    try:
        value_parsed = float(unknow_data)
        if math.isnan(value_parsed):
            return None
        else:
            return value_parsed
    except (ValueError, TypeError):
        return None


def _get_auth_token(request_data):
    try:
        authorization_header = request_data.headers['authorization']
    except KeyError:
        return ''
    if authorization_header:
        return authorization_header.split(" ")[1]
    else:
        return ''
