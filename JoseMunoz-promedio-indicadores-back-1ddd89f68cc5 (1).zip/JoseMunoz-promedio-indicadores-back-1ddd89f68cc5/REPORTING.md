
# Usar el sistema de reporting desde local

### Si es la primera vez que se ejecuta el código en el equipo:

Comenzamos iniciando una terminal dentro de la carpeta 'base' del proyecto (donde se encuentra este documento)


1º Creamos el espacio virtual de ejecución de Python:
```
python3 -m venv ./venv
```

2º Lo activamos (Según la terminal que usemos, en algunas aparecerá "(venv)" al principio):

```
source ./venv/bin/activate
```

3º Instalamos las dependencias:

```
pip install -r requirements.txt
```

4º Ejecutamos el script que ejecutará el sistema de reporting:

```
./script_reporting
```


### Si ya habías creado el espacio vitual y habías descargado las dependedncias:

Comenzamos iniciando una terminal dentro de la carpeta 'base' del proyecto (donde se encuentra este documento)

1º Activamos el entorno en nuestra terminal:

```
source ./venv/bin/activate
```

2º Ejecutamos el script que ejecutará el sistema de reporting:

```
./script_reporting
```

